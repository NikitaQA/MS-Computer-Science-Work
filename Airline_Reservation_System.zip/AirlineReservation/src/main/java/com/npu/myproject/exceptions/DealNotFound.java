package com.npu.myproject.exceptions;

public class DealNotFound extends Exception{
	private static final long serialVersionUID = 1L;
	public DealNotFound(String msg){
		super(msg);
	}

}
