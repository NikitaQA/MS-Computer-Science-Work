package com.npu.myproject.exceptions;

public class LocationNotFound extends Exception {
	private static final long serialVersionUID = 1L;

	public LocationNotFound(String msg){
		super(msg);
	}
	

}
