package com.npu.myproject.exceptions;

public class LocationDaoException extends RuntimeException{
	private static final long serialVersionUID = 1L;
	public LocationDaoException(String msg){
		super(msg);
	}
	

}
