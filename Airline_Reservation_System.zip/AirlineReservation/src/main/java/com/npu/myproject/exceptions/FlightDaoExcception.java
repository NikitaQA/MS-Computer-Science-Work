package com.npu.myproject.exceptions;

public class FlightDaoExcception extends RuntimeException {
		private static final long serialVersionUID = 1L;
		public  FlightDaoExcception(String msg){
			super(msg);
		}
		
}

