package com.npu.myproject.forms;

public class ResultForm {

private String selectedFlight;
	
	public String getSelectedFlight() {
		return selectedFlight;
	}
	public void setSelectedFlight(String selectedFlight) {
		this.selectedFlight = selectedFlight;
	}
	
}
