package dataaccess;
public interface ContactInfoConstants 
{
    int NAME_SIZE=20;
    int ADDRESS_SIZE=50;
    int PH_NO_SIZE=10;    
}
